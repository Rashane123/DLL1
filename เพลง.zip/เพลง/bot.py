import discord
from discord.ext import commands
import yt_dlp
import asyncio
import os
import sys

# ==============================================================================
# ตั้งค่า yt-dlp
# ==============================================================================
YDL_OPTS = {
    'format': 'bestaudio/best',
    'quiet': True,
    'no_warnings': True,
    'default_search': 'ytsearch',
    'noplaylist': True,
    'source_address': '0.0.0.0',
}

FFMPEG_OPTS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn',
}

# ==============================================================================
# ตั้งค่าบอท
# ==============================================================================
intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(
    command_prefix='!',
    description='บอทเปิดเพลงจาก YouTube',
    intents=intents,
)

# state ต่อ guild
queues: dict[int, list] = {}        # คิวเพลง
now_playing: dict[int, dict] = {}   # เพลงที่กำลังเล่น
idle_timers: dict[int, asyncio.Task] = {}  # timer ออกอัตโนมัติ

# ==============================================================================
# ฟังก์ชันช่วย
# ==============================================================================
def get_queue(guild_id: int) -> list:
    if guild_id not in queues:
        queues[guild_id] = []
    return queues[guild_id]


async def search_youtube(query: str) -> dict | None:
    """ค้นหาเพลงจาก YouTube แล้วคืน dict {title, url}"""
    loop = asyncio.get_event_loop()

    def _extract():
        with yt_dlp.YoutubeDL(YDL_OPTS) as ydl:
            if not query.startswith('http'):
                info = ydl.extract_info(f'ytsearch:{query}', download=False)
                entries = info.get('entries')
                return entries[0] if entries else None
            else:
                return ydl.extract_info(query, download=False)

    data = await loop.run_in_executor(None, _extract)
    if not data:
        return None

    # ถ้าเป็น playlist ใช้เพลงแรก
    if 'entries' in data:
        data = data['entries'][0]

    return {
        'title': data.get('title', 'Unknown'),
        'webpage_url': data.get('webpage_url') or data.get('url'),
    }


async def get_stream_url(webpage_url: str) -> str:
    """ดึง stream URL จาก YouTube"""
    loop = asyncio.get_event_loop()

    def _extract():
        opts = {**YDL_OPTS, 'noplaylist': True}
        with yt_dlp.YoutubeDL(opts) as ydl:
            data = ydl.extract_info(webpage_url, download=False)
            if 'entries' in data:
                data = data['entries'][0]
            return data['url']

    return await loop.run_in_executor(None, _extract)


def play_next(ctx: commands.Context):
    """เล่นเพลงถัดไปในคิว"""
    guild_id = ctx.guild.id
    queue = get_queue(guild_id)

    if queue:
        _cancel_idle_timer(guild_id)
        song = queue.pop(0)
        now_playing[guild_id] = song
        bot.loop.create_task(_play_song(ctx, song))
    else:
        now_playing[guild_id] = None
        _start_idle_timer(ctx)


async def _play_song(ctx: commands.Context, song: dict):
    """โหลด stream และเริ่มเล่น"""
    try:
        stream_url = await get_stream_url(song['webpage_url'])
        source = discord.FFmpegPCMAudio(stream_url, **FFMPEG_OPTS)
        ctx.voice_client.play(
            discord.PCMVolumeTransformer(source, volume=0.5),
            after=lambda _: play_next(ctx),
        )
        await ctx.send(f'🎶 กำลังเล่น: **{song["title"]}**')
    except Exception as e:
        await ctx.send(f'❌ เล่นเพลงไม่ได้: {e}')
        play_next(ctx)  # ข้ามไปเพลงถัดไป


# ==============================================================================
# Idle timer — ออกจากห้องถ้าไม่มีการใช้งาน 5 นาที
# ==============================================================================
def _start_idle_timer(ctx: commands.Context):
    guild_id = ctx.guild.id
    channel = ctx.channel

    async def _wait():
        try:
            await asyncio.sleep(300)
            vc = ctx.voice_client
            if vc and vc.is_connected() and not vc.is_playing():
                await vc.disconnect()
                get_queue(guild_id).clear()
                now_playing[guild_id] = None
                await channel.send('👋 ออกจากห้องเสียงอัตโนมัติ (ไม่มีการใช้งาน 5 นาที)')
        except asyncio.CancelledError:
            pass

    idle_timers[guild_id] = bot.loop.create_task(_wait())


def _cancel_idle_timer(guild_id: int):
    task = idle_timers.pop(guild_id, None)
    if task:
        task.cancel()

# ==============================================================================
# Events
# ==============================================================================
@bot.event
async def on_ready():
    print('=' * 40)
    print(f'✅ บอทออนไลน์: {bot.user}')
    print(f'🆔 ID: {bot.user.id}')
    print('คำสั่ง: !play  !skip  !queue  !stop  !pause  !resume')
    print('=' * 40)


@bot.event
async def on_voice_state_update(member, before, after):
    """เคลียร์ state เมื่อบอทถูกตัดออก"""
    if member.id != bot.user.id:
        return
    if before.channel and not after.channel:
        guild_id = member.guild.id
        get_queue(guild_id).clear()
        now_playing[guild_id] = None
        _cancel_idle_timer(guild_id)

# ==============================================================================
# Commands
# ==============================================================================
@bot.command(name='play', aliases=['p'], help='เล่นเพลงจาก YouTube  !play <ชื่อเพลง หรือ URL>')
async def play(ctx: commands.Context, *, query: str):
    # ตรวจสอบว่าผู้ใช้อยู่ในห้องเสียง
    if not ctx.author.voice:
        return await ctx.send('❌ คุณต้องอยู่ในห้องเสียงก่อนนะ!')

    channel = ctx.author.voice.channel

    # เข้าร่วมหรือย้ายห้อง
    if not ctx.voice_client:
        perms = channel.permissions_for(ctx.me)
        if not perms.connect or not perms.speak:
            return await ctx.send('❌ บอทไม่มีสิทธิ์เข้าห้องนี้')
        await channel.connect()
    elif ctx.voice_client.channel != channel:
        await ctx.voice_client.move_to(channel)

    async with ctx.typing():
        song = await search_youtube(query)
        if not song:
            return await ctx.send('❌ ไม่พบเพลงนี้ใน YouTube')

        queue = get_queue(ctx.guild.id)
        queue.append(song)

        is_busy = ctx.voice_client.is_playing() or ctx.voice_client.is_paused()
        if is_busy or now_playing.get(ctx.guild.id):
            pos = len(queue)
            await ctx.send(f'✅ เพิ่มลงคิว #{pos}: **{song["title"]}**')
        else:
            play_next(ctx)


@bot.command(name='skip', aliases=['s'], help='ข้ามเพลงปัจจุบัน')
async def skip(ctx: commands.Context):
    vc = ctx.voice_client
    if vc and vc.is_playing():
        vc.stop()
        await ctx.send('⏭️ ข้ามเพลงแล้ว!')
    else:
        await ctx.send('❌ ไม่มีเพลงที่กำลังเล่นอยู่')


@bot.command(name='pause', help='หยุดชั่วคราว')
async def pause(ctx: commands.Context):
    vc = ctx.voice_client
    if vc and vc.is_playing():
        vc.pause()
        await ctx.send('⏸️ หยุดชั่วคราวแล้ว  พิมพ์ !resume เพื่อเล่นต่อ')
    else:
        await ctx.send('❌ ไม่มีเพลงที่กำลังเล่นอยู่')


@bot.command(name='resume', aliases=['r'], help='เล่นต่อหลัง pause')
async def resume(ctx: commands.Context):
    vc = ctx.voice_client
    if vc and vc.is_paused():
        vc.resume()
        await ctx.send('▶️ เล่นต่อแล้ว!')
    else:
        await ctx.send('❌ ไม่มีเพลงที่ถูก pause อยู่')


@bot.command(name='queue', aliases=['q'], help='ดูรายชื่อเพลงในคิว')
async def show_queue(ctx: commands.Context):
    queue = get_queue(ctx.guild.id)
    current = now_playing.get(ctx.guild.id)

    if not current and not queue:
        return await ctx.send('📭 คิวเพลงว่างเปล่า')

    lines = []
    if current:
        lines.append(f'🔊 **กำลังเล่น:** {current["title"]}')
    if queue:
        lines.append('\n📜 **รอในคิว:**')
        for i, song in enumerate(queue[:10], 1):
            lines.append(f'  {i}. {song["title"]}')
        if len(queue) > 10:
            lines.append(f'  *(และอีก {len(queue) - 10} เพลง)*')
    else:
        lines.append('\n📭 ไม่มีเพลงในคิวถัดไป')

    await ctx.send('\n'.join(lines))


@bot.command(name='stop', help='หยุดเพลงทั้งหมดและออกจากห้อง')
async def stop(ctx: commands.Context):
    vc = ctx.voice_client
    if vc:
        get_queue(ctx.guild.id).clear()
        now_playing[ctx.guild.id] = None
        _cancel_idle_timer(ctx.guild.id)
        await vc.disconnect()
        await ctx.send('👋 หยุดเพลงและออกจากห้องแล้ว')
    else:
        await ctx.send('❌ บอทไม่ได้อยู่ในห้องเสียง')


@bot.command(name='np', help='ดูเพลงที่กำลังเล่น')
async def now_playing_cmd(ctx: commands.Context):
    current = now_playing.get(ctx.guild.id)
    if current:
        await ctx.send(f'🎵 กำลังเล่น: **{current["title"]}**')
    else:
        await ctx.send('❌ ไม่มีเพลงที่กำลังเล่นอยู่')

# ==============================================================================
# รันบอท
# ==============================================================================
if __name__ == '__main__':
    # อ่าน token จาก environment variable หรือไฟล์ .env
    token = os.environ.get('TOKEN') or os.environ.get('queshane')

    if not token and os.path.exists('.env'):
        with open('.env', encoding='utf-8') as f:
            for line in f:
                key, _, val = line.strip().partition('=')
                if key.strip() in ('TOKEN', 'queshane'):
                    token = val.strip()
                    break

    if not token:
        print('❌ ไม่พบ Token! ใส่ TOKEN=xxxx ใน .env หรือ environment variable')
        sys.exit(1)

    bot.run(token)
